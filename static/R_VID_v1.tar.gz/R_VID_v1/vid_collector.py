#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import json

# REAL PATH TO PARENT FOLDER
filesys_path = "/var/www/svabis.eu/media/video_new/"
# 0. ELEMENT IS WHAT TO REPLACE FROM FILE
# 1. ELEMENT IS WITH WHAT TO REPLACE FOR CORRECT APACHE/NGIX/e.t.c WEBSERVER PATH
replace_path = ["/var/www/svabis.eu/", "https://svabis.eu/"]
# PATH FOR VIDEO LIST TO BE CREATED (MUST BE IN REACH FOR WEBSERVER)
out_file = "/var/www/svabis.eu/static/vid.json"

f = []
for (dirpath, dirnames, filenames) in os.walk(filesys_path):
    f.extend( [dirpath, filenames] )

v = []
temp = ""
for i, l in enumerate( f ):
    if i%2 == 0:
        temp = l+"/"
    else:
        for j in l:
            if j.endswith(".mp4"):
                v.append( (temp+j).replace(replace_path[0], replace_path[1]) )

v.sort()

out = (json.dumps(v))

f = open(out_file,"w")
f.write( "data = '" + out + "';")
f.close()

